#include <stdio.h>
#include <stdlib.h>

//Fun��o principal do programa
void main(){

    //Imprime na tela
    printf("Oi mundo!");

    //Pausa o programa ap�s executar
    system("pause");

}

